﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 30f;

    [SerializeField] private Vector2 startDirection;
    [SerializeField] private Transform ballStartPosition;

    private Rigidbody2D rigidbody;
    private bool isMoving = false;

    private void Awake()
    {
        rigidbody = GetComponent<Rigidbody2D>();    
    }

    private void Update()
    {

        if (Input.GetButtonDown("Jump") && !isMoving)
        {
            StartBall();
        }
    }

    private void StartBall()
    {
        isMoving = true;
        //Vector2 startDirection2 = GetRandomDirection();
        rigidbody.velocity = moveSpeed * startDirection;
    }

    private void StopBall()
    {
        isMoving = false;
        rigidbody.velocity = Vector2.zero;
    }

    public void ResetBall()
    {
        transform.position = ballStartPosition.position;
        StopBall();
        moveSpeed = 30f;
    }

    /*private Vector2 GetRandomDirection()
    {
        int xDir = Random.Range(0, 2);
        xDir = xDir == 0 ? -1 : 1;
        float yDir = Random.Range(-1f, 1f);
        return new Vector2(xDir, yDir).normalized;
    }*/

    public void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.name == "Player1" || other.gameObject.name == "Player2")
        {
            moveSpeed = moveSpeed + 1f;
            Vector2 position = this.transform.position;
            rigidbody.velocity = -position * 2f;
        }
    }
}
