﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance = null;

    [SerializeField] private GameObject player1;
    [SerializeField] private GameObject player2;

    [SerializeField] private GameObject ball;

    private int player1score = 0;
    private int player2score = 0;

    private Ball ballScript;

    private void Awake()
    {
        if (Instance != null)
        {
            Destroy(this);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(Instance);

        ballScript = ball.GetComponent<Ball>();
    }

    public void Score(GameObject player)
    {
        if (player == player1)
        {
            player2score++;
        }
        else
        {
            player1score++;
        }
        ResetBall();
    }

    private void ResetBall()
    {
        ballScript.ResetBall();
    }
}
