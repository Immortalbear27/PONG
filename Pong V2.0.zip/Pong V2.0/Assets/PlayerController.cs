﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 5f;

    private float moveValue;

    private Rigidbody2D rigidbody;

    private void Awake()
    {
        rigidbody = GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        moveValue = Input.GetAxis("Vertical");
    }

    private void FixedUpdate()
    {
        rigidbody.velocity = new Vector2(rigidbody.velocity.x, moveValue * moveSpeed);
    }
}
